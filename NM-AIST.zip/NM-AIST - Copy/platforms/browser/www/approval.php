<?php
 include "db.php";
 if(isset($_POST['approval']))
 {
 $id=$_POST['id'];
 $status="true";
 $q=mysqli_query($con,"UPDATE `group` SET `status`='$status' where `id`='$id'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>