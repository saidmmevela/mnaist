<?php
include "db.php";
$data=array();
if(isset($_GET['id'])){
	$id=$_GET['id'];
	
	$qq=mysqli_query($con,"select * FROM `comment` JOIN `user`  where comment.fromm=user.email AND too='$id'   ORDER BY comment.id ASC");
		if($qq){
		while($row = $qq->fetch_assoc()){
		//$data[]=$row;
		//echo json_encode(('Success', $data));	
		$reslt="<div class='message message-received'><div class='message-content'><div class='message-name'>". $row['username']. "</div><div class='message-bubble' ><div class='message-text'>" . $row['cmt']. "</div></div></div></div>";
	  echo $reslt;
	//echo "success";
		}
		}
}

//echo json_encode($data);
//echo json_encode(new retObj('Success', $a[$id]));
?>