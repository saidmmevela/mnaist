<?php
include "db.php";
$data=array();
if(isset($_GET['email'])){
	
	$email=$_GET['email'];
	
	$q1=mysqli_query($con,"select * FROM `user` where email='$email'");
		
	if($q1->num_rows > 0){
		echo "success";		
	}
	else{
		echo "error";
	}
?>				