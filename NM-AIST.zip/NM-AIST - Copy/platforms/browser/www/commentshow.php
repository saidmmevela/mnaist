<?php
include "db.php";
$data=array();
$id=$_POST['id'];
$too=39;
$q=mysqli_query($con,"select * FROM `comment` JOIN `user` ON comment.fromm=user.email  where comment.too='$too'");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>