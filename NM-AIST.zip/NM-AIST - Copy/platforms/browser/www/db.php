<?php
// header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","nmaistserver") or die ("could not connect database");


 //$con = mysqli_connect("db4free.net:3306","nmaistserver","nmaist78","nmaistserver") or die ("could not connect database");
 
 
/*$username ="nmaistserver"; 
$password = "nmaist78"; 
$host = "db4free.net:3306"; 
$dbname = "nmaistserver"; 

$options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'); 

try 
{ 
    $db = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8", $username, $password, $options); 
} 
catch(PDOException $ex) 
{ 
    die("Failed to connect to the database: " . $ex->getMessage()); 
}


$mysqli = new mysqli($aConnection['db4free.net:3306'], $aConnection['nmaistserver'], $aConnection['nmaist78'], null, $aConnection['3306'], null);
if ( $mysqli->connect_error ) {
  $rc = 175;
  $msg = $mysqli->connect_error . ' (' . $mysqli->connect_errno . ')' . " (rc=$rc).";
  tee('  ERROR: ' . $msg);
  return array($rc, null);
}
*/
?>