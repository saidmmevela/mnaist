<?php
include "db.php";
			
if(isset($_POST['disjoin'])){
$email=$_POST['email'];
$id=$_POST['id'];
$q2=mysqli_query($con,"select * FROM `group` where gadmin='$email' and id='$id'");
$q1=mysqli_query($con,"select * FROM `group_member` where email='$email' and group_id='$id'");
if($q2->num_rows > 0){

$qq=mysqli_query($con,"DELETE FROM `group` WHERE gadmin='$email' and id='$id'");

if($qq){
	echo "success";
}
else{
	echo "error";
}
}
if($q1->num_rows > 0){
//$q1=mysqli_query($con,"UPDATE `group_member` SET `email`='$email' where `email`='$email'");
$q=mysqli_query($con,"DELETE FROM `group_member` WHERE email='$email' and group_id='$id' ");

if($q){
	echo "success";
}
else{
	echo "error";
}

}
}

?>			