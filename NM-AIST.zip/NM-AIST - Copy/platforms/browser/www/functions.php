<?php
// connect to database
session_start();
$db = mysql_connect("localhost","root","");
mysql_select_db("nmaist",$db) or die("connection feild");

function display_error() {
	global $errors;

	if (count($errors) > 0){
		echo '<div class="error">';
			foreach ($errors as $error){
				echo $error .'<br>';
			}
		echo '</div>';
	}
}

if(isset($_POST['signup'])){
	signup();
	}
//function to send signup details to the database
function signup(){
global $db;
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];


  

$sqlquery="SELECT* FROM registered_email where email='$email'";
$sqlResult=mysql_query($sqlquery);
$sqlReturn=mysql_fetch_assoc($sqlResult);

if($sqlReturn['email']==$email){
	
$sqlquer="SELECT* FROM user";
$sqlReslt=mysql_query($sqlquer);
$sqlRetrn=mysql_fetch_assoc($sqlReslt);

	if($sqlRetrn['email']!=$email){
	if($sqlReturn['password']==$pwd){
		
	$sqll="INSERT INTO user (email,username,password,Fname,Lname)
VALUES  ('$email','$uname','$pwd','$fname','$lname')";
if (!mysql_query($sqll,$db)){

  die('Error: ' . mysql_error());

  }else{
	
	echo"<div class='error'><p align='center'>success sign up</p></div>";
       }
  

	}else{
	
	echo"<div class='error'><p align='center'>incorrect password</p></div>";
	}}
	else{
	
	echo"<div class='error'><p align='center'>your email already used</p></div>";
     }
		
}else{
	
	echo"<div class='error'><p align='center'>your email is not valid</p></div>";
     }

 

}


if(isset($_POST['login'])){
	login();
	}
	
//function to send signup details to the database
function login(){
global $db;

$uname=$_POST['uname'];
$pwd=$_POST['password'];


  

$slt="SELECT * FROM user  where username='$uname'  and password='$pwd' ";
$qry=mysql_query($slt);
if (!$qry)
  {

  die('Error: ' . mysql_error());

  }
else{
$num=mysql_num_rows($qry);
$fetch=mysql_fetch_assoc($qry);

if($num==1){


header('location:board.html');
$_SESSION['user']=$fetch;	
}

else{
	echo"<div class='error'><p align='center'>Wrong email or password</p></div>";
	
	}
	
}

}


if(isset($_POST['submit'])){
	post();
	}
//function to send signup details to the database
function post(){
global $db;
$title=$_POST['title'];
$upload=$_POST['upload'];
$description=$_POST['description'];
$view=0;

if (isset($_SESSION['user'])){
 $email=$_SESSION['user']['email'];

	
	$sqll="INSERT INTO posts (email,posts,Descriptions,view)
VALUES  ('$email','$title','$description','$view')";
if (!mysql_query($sqll,$db)){

  die('Error: ' . mysql_error());

  }else{
	
	echo"<div class='error'><p align='center'>success posting</p></div>";
       }
}
}




	
	
	
	


?>