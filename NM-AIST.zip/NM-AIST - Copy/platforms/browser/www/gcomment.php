<?php
 include "db.php";
 if(isset($_POST['comment']))
 {
 $userfrom=$_POST['email'];
 $rcid=$_POST['id'];
 $cmt=$_POST['cmt'];



 
 //$q1=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$userfrom'");
 //$rst = $q1->fetch_assoc();
 //$id=$rst['id'];
//if($q1){

 $q=mysqli_query($con,"INSERT INTO `group_comment` (`gpost_to`,`u_from`,`cmt`) VALUES ('$rcid','$userfrom','$cmt')");
 if($q){
  echo "success";
 
 }else{
  echo "error";
}
//}
  
 //else{	echo "error";

 //}
 
 }
 
 ?>