 <?php 
				include "db.php";
			$data=array();
			if(isset($_GET['id'])){
			$id=$_GET['id'];
			
		 $qq=mysqli_query($con,"select * FROM `group_comment` JOIN `user`  where group_comment.u_from=user.email AND group_comment.gpost_to='$id'  ORDER BY group_comment.id ASC");
			if($qq){
				while($row = $qq->fetch_assoc()){
			//$data[]=$rt;
			$reslt="<div class='message message-received'><div class='message-content'><div class='message-name'>". $row['username']. "</div><div class='message-bubble' ><div class='message-text'>" . $row['cmt']. "</div></div></div></div>";
			echo $reslt;
			
				}
				
			}
			}
			//echo json_encode($data);
			   ?>
          