<?php 
				include "db.php";
			$data=array();
			if(isset($_GET['id'])){
			$uemail=$_GET['email'];
			
			//$gad=3;
			//$min="said@nmaist.ac.tz";
			$id=$_GET['id'];
			
			$q1=mysqli_query($con,"select * FROM `group_member` where email='$uemail' and group_id='$id'");
			$q2=mysqli_query($con,"select * FROM `group` where gadmin='$uemail' and id='$id'");
			if($q2->num_rows > 0){
			
			$qq=mysqli_query($con,"select * FROM `group_post` JOIN `user`  where group_post.email=user.email AND group_post.group_id='$id'  ORDER BY group_post.id DESC");
			$q=mysqli_query($con,"select * FROM `group`  where  id='$id'");
			$rst = $q->fetch_assoc();
			if($qq){
				while($rt1 = $qq->fetch_assoc()){
					$data[]=$rt1;
			//echo json_encode(new retObj('Success', $data));	
			
			
				}
			}
			}
			
			/*else if($q1->num_rows > 0){
				
				$qq=mysqli_query($con,"select * FROM `group_post` JOIN `user`  where group_post.email=user.email AND group_post.group_id='$id'  ORDER BY group_post.id DESC");
			$q=mysqli_query($con,"select * FROM `group`  where  id='$id'");
			$rst = $q->fetch_assoc();
			if($qq){
				while($rt2 = $qq->fetch_assoc()){
					$data[]=$rt2;
			//echo json_encode(new retObj('Successi', $data));	
			echo json_encode( $data));
				}
			}
				
				
			}
			else if($q1->num_rows == 0){
				$q=mysqli_query($con,"select * FROM `group`  where  id='$id'");
				$rt3 = $q->fetch_assoc();
				$data[]=$rt3;
				//echo json_encode(new retObj('Failure',$data));
				//echo json_encode(new retObj('Success', $a[$id]));
				echo json_encode( $data));				
			}*/
	}	
echo json_encode( $data));	

?>