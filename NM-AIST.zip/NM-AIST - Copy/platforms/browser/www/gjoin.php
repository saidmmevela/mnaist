<?php
 include "db.php";
 if(isset($_POST['join']))
 {
 $email=$_POST['email'];
 $id=$_POST['id'];
$q1=mysqli_query($con,"select * FROM `group_member` where email='$email' and group_id='$id'");
if($q1->num_rows == 0){
 $q=mysqli_query($con,"INSERT INTO `group_member` (`group_id`,`email`) VALUES ('$id','$email')");
 if($q){
  echo "success";
 
 }
 else{
  echo "error";
}

 }
else{
echo "exist";
}
 }
 
 ?>