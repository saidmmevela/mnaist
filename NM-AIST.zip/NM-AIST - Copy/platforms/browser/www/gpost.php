<?php
 include "db.php";
 if(isset($_POST['signup']))
 {

 $gname=$_POST['gname'];
 $email=$_POST['email'];
 $gcategory=$_POST['gcategory'];
 $description=$_POST['description'];
 $status="false";
 $cover="default.png";
 
 //$q1=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email'");
//if($q1->num_rows >0){

 $q=mysqli_query($con,"INSERT INTO `group` (`gname`,`gadmin`,`gcategory`,`status`,`description`,`cover`) VALUES ('$gname','$email','$gcategory','$status','$description','$cover')");
 if($q){
  echo "success";
 
 }else{
  echo "error";
}
//}
  
 //else{	echo "error";

 //}
 
 }
 
 ?>