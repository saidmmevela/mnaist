<?php
include "db.php";
$data=array();
if(isset($_GET['id'])){
	$id=$_GET['id'];
	//$email=$_GET['email'];
	
	
	$qq=mysqli_query($con,"select * FROM `group`   where  id='$id' ");
	
	if($qq){
		while($row = $qq->fetch_assoc()){
		$data[]=$row;
		//echo json_encode(('Success', $data));	
		//$response_array['status'] = 'success'; 
	  //  echo json_encode($data);
			//echo "success";
		}
		
			
   
}
}
 echo json_encode($data);
//echo json_encode(new retObj('Success', $a[$id]));
?>