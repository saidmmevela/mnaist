<?php
 include "db.php";
 if(isset($_POST['signup']))
 {
 $Fname=$_POST['Fname'];
 $Lname=$_POST['Lname'];
 $Uname=$_POST['Uname'];
 $email=$_POST['email'];
$normal="normal";
 $password=$_POST['password'];
 $dp="profile.png";
 
 $q1=mysqli_query($con,"SELECT * FROM `registered_email` WHERE `email`='$email' AND `password`='$password'");
if($q1->num_rows >0){
$q2=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email'");
if($q2->num_rows ==0){
 $q=mysqli_query($con,"INSERT INTO `user` (`Fname`,`Lname`,`username`,`email`,`password`,`status`,`dp`) VALUES ('$Fname','$Lname','$Uname','$email','$password','$normal','$dp')");
 if($q){
  echo "success";
 
 }else{
  echo "error";
}}

else{
  echo "error";
}


}
  
 else{	echo "error";

 }
 
 }
 
 ?>