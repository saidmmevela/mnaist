<?php
include "db.php";
$data=array();
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$email=$_GET['email'];
	
	$q1=mysqli_query($con,"select * FROM `group_member` where email='$email' and group_id='$id'");
	//$q2=mysqli_query($con,"select * FROM `group` where gadmin='$email' and id='$id'");
			
	if($q1->num_rows > 0){
				
	//$qq=mysqli_query($con,"select * FROM `group_post` JOIN `user`  where group_post.email=user.email AND group_post.group_id='$id'  ORDER BY group_post.id DESC");
			//$q=mysqli_query($con,"select * FROM `group`  where  id='$id'");
			//$rst = $q1->fetch_assoc();
			
				while($rt1 = $q1->fetch_assoc()){
					$data[]=$rt1;
			//echo json_encode(new retObj('Successi', $data));	
			//echo json_encode( $data));
			  // echo "success";
				}
		
				
				
			}
	else if($q1->num_rows == 0){
				$q=mysqli_query($con,"select * FROM `group`  where  id='$id'");
				$rt3 = $q->fetch_assoc();
				$data[]=$rt3;
				//echo json_encode(new retObj('Failure',$data));
				//echo json_encode(new retObj('Success', $a[$id]));
				//echo json_encode( $data));
				//echo "error";				
			}
			
    echo json_encode($data);
}


//echo json_encode(new retObj('Success', $a[$id]));
?>