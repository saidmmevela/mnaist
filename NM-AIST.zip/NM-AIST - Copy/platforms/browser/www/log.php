<?php
include "db.php";	
//function to send signup details to the database
session_start();

if(isset($_POST['login']))
{
	 $uname = $_POST['uname'];
    $password = $_POST['password'];
	$q=mysqli_query($con,"SELECT * FROM `user`  where `username`='$uname' and `password`='$password'");
 
//$num=mysqli_num_rows($qry);
//$row = $result->num_rows();
//$fetch=mysqli_fetch_assoc($qry);
$rows = $result->fetch_assoc();

if($result->num_rows > 0)

echo "success";
//$_SESSION['user']=$fetch;	
    else
        echo "error";
}

	



 mysql_close($db);
?>