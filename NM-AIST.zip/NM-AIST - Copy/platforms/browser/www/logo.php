<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>NM-AIST</title>
    <!-- Path to Framework7 Library CSS-->
	<link rel="stylesheet" type="text/css" href="css/ionic.css">
    <link rel="stylesheet" href="css/framework7.ios.min.css">
    <link rel="stylesheet" href="css/framework7.ios.colors.min.css">
	 <script type="text/javascript" src="js/jquery.js"></script>
    <!-- Path to your custom app styles-->
    <link rel="stylesheet" href="css/my-app.css">
	<link rel="stylesheet" type="text/css" href="css/ionic.css">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        var url = "http://localhost/app/NM-AIST/www/bigview.php";
        $.getJSON(url, function(result) {
            console.log(result);
            $.each(result, function(i, field) {
                var id = field.id;
                var email = field.email;
                var posts = field.posts;
                var view = field.view;
                $("#listview").append("<a class='item' href='bigview.html?id=" + id + "&email=" + email + "&posts=" + posts + "&view=" + view + "'><span class='item-note'> " + view + "  views</span><h2>" + email + " </h2><p>" + posts + "</p></a>");
            });
        });
    });
    </script>
  </head>
  <body>
    <!-- Status bar overlay for fullscreen mode-->
    <div class="statusbar-overlay"></div>
    <!-- Panels overlay-->
    <div class="panel-overlay"></div>
    <!-- Left panel with reveal effect-->
    <div class="panel panel-left panel-reveal">
	
      <div class="content-block">
	  <div data-page="index" class="page">
	   <div class="page-content">
         <div class="list-block">
                <ul>
                  <li><a  href="board.html" class="item-link">
                      <div class="item-content">
                        <div class="item-inner"> 
                          <div class="item-title">HOME</div>
                        </div>
                      </div></a></li>
                  <li><a href="notice.html" class="item-link">
                      <div class="item-content"> 
                        <div class="item-inner">
                          <div class="item-title">NOTICE BOARD</div>
                        </div>
                      </div></a></li>
                  <li><a href="form.html" class="item-link">
                      <div class="item-content"> 
                        <div class="item-inner">
                          <div class="item-title">INTEREST</div>
                        </div>
                      </div></a></li>
					<li><a href="form.html" class="item-link">
                      <div class="item-content"> 
                        <div class="item-inner">
                          <div class="item-title">BROADCAST</div>
                        </div>
                      </div></a></li>
					 <li><a href="form.html" class="item-link">
                      <div class="item-content"> 
                        <div class="item-inner">
                          <div class="item-title">GET TOGETHER</div>
                        </div>
                      </div></a></li>
					 <li><a href="form.html" class="item-link">
                      <div class="item-content"> 
                        <div class="item-inner">
                          <div class="item-title">MARKET</div>
                        </div>
                      </div></a></li>
                </ul>
              </div>
              </div>
      </div>
      </div>
    </div>
    <!-- Right panel with cover effect-->
    <div class="panel panel-right panel-cover">
      <div class="content-block">
        <p>Right panel content goes here</p>
      </div>
    </div>
    <!-- Views-->
    <div class="views">
      <!-- Your main view, should have "view-main" class-->
      <div class="view view-main">
        <!-- Top Navbar-->
        <div class="navbar">
          <div class="navbar-inner">
		  <div class="left"><a href="board.html" class="back link external"> <i class="icon icon-back"></i> back</a></div>
       <div class="center sliding">Notice Board</div>		 
		 <div class="right">
              <!-- Right link contains only icon - additional "icon-only" class--><a href="#" class="link icon-only open-panel"> <i class="icon icon-bars"></i></a>
            </div>
            <!-- We have home navbar without left link-->
            
             
          </div>
        </div>
        <!-- Pages, because we need fixed-through navbar and toolbar, it has additional appropriate classes-->
        <div class="pages navbar-through toolbar-through">
          <!-- Page, data-page contains page name-->
          <div data-page="index" class="page">
            <!-- Scrollable page content-->
            <div class="page-content">
               <div class="content-block-title"><a href="newpost.html" class="item-link external" >share new issues</a></div>
            <ul class="list" id="listview">
    </ul>
              <!--<div class="card demo-facebook-card" id="listview">
              </div>-->
             
            </div>
          </div>
        </div>
        <!-- Bottom Toolbar-->
       
      </div>
    </div>
    <!-- Path to Framework7 Library JS-->
    <script type="text/javascript" src="js/framework7.min.js"></script>
    <!-- Path to your app js-->
    <script type="text/javascript" src="js/my-app.js"></script>
  </body>
</html>