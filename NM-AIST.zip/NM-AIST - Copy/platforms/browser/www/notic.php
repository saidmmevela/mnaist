
<!-- We don't need full layout here, because this page will be parsed with Ajax-->
<!-- Top Navbar-->
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"><span>Back</span></i></a></div>
    <div class="center sliding">Notice Board</div>
    <div class="right">
      <!-- Right link contains only icon - additional "icon-only" class--><a href="#" class="link icon-only open-panel"> <i class="icon icon-bars"></i></a>
    </div>
  </div>
</div>
<div class="pages">
  <!-- Page, data-page contains page name-->
  <div data-page="services" class="page">
    <!-- Scrollable page content-->
	
	<div class="page-content">

                <div class="row">
                  <div class="col-50"><a href="newpost.php" >share new issues</a></div>
                  
                
              </div>
   
 <?php
	$db = mysql_connect("localhost","root","");
    mysql_select_db("nmaist",$db) or die("connection feild");

	$sqlquery="SELECT* FROM posts";
   $sqlResult=mysql_query($sqlquery);
    
	while($sqlReturn=mysql_fetch_assoc($sqlResult)){
	?>
<div class="card demo-facebook-card">
  <div class="card-header">
    
    <div class="demo-facebook-name"><?php echo $sqlReturn['email'];   ?></div></div>
	<div class="card-header">
    <div class="demo-facebook-date">Monday at 2:15 PM</div>
  </div>

  <a href="bigview.php?id=<?php echo $sqlReturn['id']; ?>" class="item-link item-content">
  <div class="card-content card-content-padding">
    <p><?php echo $sqlReturn['posts'];   ?></p>
   
  </div></a>
  <div class="card-footer"><a href="#" class="link">view<span class="badge color-green"><?php echo $sqlReturn['view'];   ?></span></a><a href="#" class="link">Comment</a></div>
</div>
<?php }?>

  
  
		  
		  
  </div>
  </div>
</div>