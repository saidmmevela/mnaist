<?php
 include "db.php";
 if(isset($_POST['newpost']))
 {
	
		 
 $posts=$_POST['posts'];
 $view=$_POST['view'];
 $Descriptions=$_POST['description'];
 
 $email=$_POST['email'];
 $q1=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email'");
 if($q1->num_rows >0){
 
 $q=mysqli_query($con,"INSERT INTO `posts` (`posts`,`Descriptions`,`email`) VALUES ('$posts','$Descriptions','$email')");
 if($q){
  echo "success";
 
 }else{
  echo "error";
 }}
 else{
  echo "error";
 }
	
 }
 ?>