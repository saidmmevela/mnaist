<?php
include "db.php";
$data=array();
if(isset($_GET['email'])){
	
	$email=$_GET['email'];
	
	$qq=mysqli_query($con,"select * FROM `user` where email='$email'");
	if($qq){
				while($rt2 = $qq->fetch_assoc()){
					//$data[]=$rt2;
					$reslt="<div class='card-content'><img src='upload/".$rt2['dp']."' style='margin-left: auto; margin-right: auto; display: block; width:50%;border-radius: 50%;'><p align='center'>".$rt2['username']."</p></div>";
					echo $reslt;
	}
}}
//echo json_encode($data);

//echo json_encode(new retObj('Success', $a[$id]));
?>