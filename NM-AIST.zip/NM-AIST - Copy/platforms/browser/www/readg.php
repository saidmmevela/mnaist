<?php
include "db.php";
$data=array();
$false="true";
$q=mysqli_query($con,"select * FROM `group`  where status='$false' ORDER BY group.id DESC");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>