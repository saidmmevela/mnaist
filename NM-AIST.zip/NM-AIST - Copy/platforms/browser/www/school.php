<?php include('fuchtion.php')    ?>
<!-- We don't need full layout here, because this page will be parsed with Ajax-->
<!-- Top Navbar-->
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span>Back</span></a></div>
    <div class="center sliding">School Registration</div>
    <div class="right">
      <!-- Right link contains only icon - additional "icon-only" class--><a href="#" class="link icon-only open-panel"> <i class="icon icon-bars"></i></a>
    </div>
  </div>
</div>
<div class="pages">
  <!-- Page, data-page contains page name-->
  <div data-page="about" class="page">
    <!-- Scrollable page content-->
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
		<form name="visit" method="post">
<h2 align="center">Registration</h2>';

<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>school information</h3></legend>

<table border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >
<tr><td><fieldset><table ><tr><td >school name</td><td align="right" ><input type="text" name="Vnumber" required></td></tr></table></fieldset></td></tr>
<tr><td><fieldset><table ><tr><td >shool moto</td><td align="right" ><input type="text" name="no_mimba_kusajiliwa"  required></td></tr></table></fieldset></td></tr>
<tr><td><fieldset><table ><tr><td >registration number</td><td align="right"><input type="number" name="uzito" min="1" required></td></tr></table></fieldset></td></tr>
<tr><td><fieldset><table ><tr><td >password</td><td align="right"><input type="text" name="albumin" required></td></tr></table></fieldset></td></tr>
<tr><td><fieldset><table ><tr><td >district</td><td align="right"><input type="text" name="mkojo_sukari" required></td></tr></table></fieldset></td></tr>
<tr><td><fieldset><table ><tr><td>region</td><td align="right"><input type="text" name="kimo_mimba"  required></td></tr></table></fieldset></td></tr>
<tr><td  align="center"><input type="submit" name="bfregister" value="Register" ><input type="reset" name="reset" value="cancel"></td></tr>

</table></fieldset>
</table></fieldset></form>

        </div>
      </div>
    </div>
  </div>
</div>