
<!-- We don't need full layout here, because this page will be parsed with Ajax-->
<!-- Top Navbar-->
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span>Back</span></a></div>
    <div class="center sliding">About</div>
    <div class="right">
      <!-- Right link contains only icon - additional "icon-only" class--><a href="#" class="link icon-only open-panel"> <i class="icon icon-bars"></i></a>
    </div>
  </div>
</div>
<div class="pages">
  <!-- Page, data-page contains page name-->
  <div data-page="about" class="page">
    <!-- Scrollable page content-->
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
		 <?php 
		 if($_GET['id']){
		 $id=$_GET['id'];
		$db = mysql_connect("localhost","root","badchata");
mysql_select_db("shule",$db) or die("connection feild");

$sel="SELECT * FROM user WHERE userID=$id";
$reslt=mysql_query($sel);
$row=mysql_fetch_array($reslt);
		?>
          <h3 align="center"><?php echo $row['name'];?></h3>
		  <p><?php echo $row['pic'];?></p>
		  <?php } ?>
         </div>
      </div>
    </div>
  </div>
</div>