
<!-- We don't need full layout here, because this page will be parsed with Ajax-->
<!-- Top Navbar-->
<div class="navbar">
  <div class="navbar-inner">
    <div class="left"><a href="#" class="back link"> <i class="icon icon-back"></i><span>Back</span></a></div>
    <div class="center sliding">Services</div>
    <div class="right">
      <!-- Right link contains only icon - additional "icon-only" class--><a href="#" class="link icon-only open-panel"> <i class="icon icon-bars"></i></a>
    </div>
  </div>
</div>
<div class="pages">
  <!-- Page, data-page contains page name-->
  <div data-page="services" class="page">
    <!-- Scrollable page content-->
    <div class="page-content">
      <div class="content-block">
        <div class="content-block-inner">
		 <div class="list-block">
		 <?php 
		$db = mysql_connect("localhost","root","badchata");
mysql_select_db("shule",$db) or die("connection feild");
$sel="SELECT * FROM user";
$reslt=mysql_query($sel);
while($row=mysql_fetch_array($reslt)){
		?>
                <ul>
                  <li><a href="schoolview.php?id=<?php echo $row['userID'];?>" class="item-link">
                      <div class="item-content">
                        <div class="item-inner"> 
                          <div class="item-title"><?php echo $row['name'];?></div>
                        </div>
                      </div></a></li>
					   <?php } ?></ul>
              </div>
          </div>
      </div>
    </div>
  </div>
</div>