<?php
 include "db.php";
 session_start();
 if(isset($_POST['login']))
 {
 
 $email=$_POST['email'];
$admin="admin";
$normal="normal";
 $password=$_POST['password'];
 $q=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email' AND `password`='$password'");
// $q1=mysqli_query($con,"SELECT * FROM `user` WHERE `email`='$email' AND `password`='$password' AND `status`='$admin'");

 $rst = $q->fetch_assoc();
 $row1 = mysqli_fetch_array($q);
 
 
 if($q->num_rows > 0){
	 
	 if($rst['status']==$normal){
		 
 echo "success";}
	else{
		echo "admin";
	}

}

else{ 
 echo "error";
 }
 
 }
 ?>