<?php

include "upltest.php";

?>
<html>
<head>
</head>
<body>
<form method="post"  enctype="multipart/form-data">
<input type="file" name="fileToUpload" >
<input type="submit" name="submit" value="submit">
</form>
</body>
</html>