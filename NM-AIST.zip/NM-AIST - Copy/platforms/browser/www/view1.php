<?php
include "db.php";
$data=array();
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$q=mysqli_query($con,"select * FROM `posts` where `id`='$id'");
	if($q){
			$rst = $q->fetch_assoc();
			$view=$rst['view']+1;
			$q1=mysqli_query($con,"UPDATE `posts` SET `view`='$view' where `id`='$id'");
					
			}
	
}

//echo json_encode($data);
//echo json_encode(new retObj('Success', $a[$id]));
?>