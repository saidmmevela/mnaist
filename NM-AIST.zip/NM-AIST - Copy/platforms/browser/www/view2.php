 <?php 
				include "db.php";
			$data=array();
			if(isset($_GET['id'])){
			$id=$_GET['id'];
			$q=mysqli_query($con,"select * FROM `group_post` where `id`='$id'");
			if($q){
				$rst = $q->fetch_assoc();
				$view=$rst['view']+1;
				$q1=mysqli_query($con,"UPDATE `group_post` SET `view`='$view' where `id`='$id'");
			
			}
		 
			}
			//echo json_encode($data);
			   ?>
          