<?php
include "db.php";
$data=array();
$id=$_GET['id'];
$q=mysqli_query($con,"select * FROM `group_post` JOIN `user` ON group_post.email=user.email  where group_id='$id' ORDER BY group.id DESC ");
while ($row=@+
mysqli_fetch_object($q)){
 $data[]=$row;

 }
echo json_encode($data);
?>