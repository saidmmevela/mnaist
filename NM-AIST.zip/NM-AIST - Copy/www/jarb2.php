<?php
include "db.php";
$data=array();
if(isset($_GET['id'])){
	$id=$_GET['id'];
	//$email=$_GET['email'];
	
	
	$qq=mysqli_query($con,"select group_post.id,group_post.group_id,group_post.email,user.username,group_post.post,group_post.description,group.gname,group.gadmin,group_post.pic,user.dp,group_post.date,group_post.time,group_post.view FROM `group_post` JOIN `user` ON group_post.email=user.email JOIN `group` ON  group_post.group_id=group.id where group_id='$id'  ORDER BY group_post.id DESC");
	
	if($qq){
		while($row = $qq->fetch_assoc()){
		//$data[]=$row;
		//echo json_encode(('Success', $data));	
		//$response_array['status'] = 'success'; 
	  //  echo json_encode($data);
			//echo "success";
			if($row['pic']){
			$reslt="<a class = 'link external' style='color:maroon;'  href='grouppostview.html?id=".$row['id']."&gid=".$row['group_id']."&email=".$row['email']."&username=".$row['username']."&post=".$row['post']."&gname=".$row['gname']."&gadmin=".$row['gadmin']."&description=".$row['description']."&pic=".$row['pic']."&dp=".$row['dp']."'><div class='card demo-facebook-card'  style='background-color:#ADD8E6;color:maroon;'><div class='card-header'><div class='demo-facebook-avatar'><img src='https://nmaist.000webhostapp.com/upload/".$row['dp']."' alt='' style='width:34px;height:34px;border-radius:100%;' /> ".$row['username']."</div><div class='demo-facebook-date'>".$row['time']."</div></div><div class='card-content'> <h3 style='color:maroon;'>".$row['post']."</h3><img src='https://nmaist.000webhostapp.com/upload/".$row['pic']."' alt='' style='width:100%;height:100%;'></div><div class='card-footer'> <span>".$row['date']." </span><span class='item-note'> ".$row['view']."  views</span></div></div></a>";
			echo $reslt;
			}
			else if(!$row['pic']){
			$reslt="<a class = 'link external' style='color:maroon;'  href='grouppostview.html?id=".$row['id']."&gid=".$row['group_id']."&email=".$row['email']."&username=".$row['username']."&post=".$row['post']."&gname=".$row['gname']."&gadmin=".$row['gadmin']."&description=".$row['description']."&dp=".$row['dp']."'><div class='card demo-facebook-card'  style='background-color:#ADD8E6;color:maroon;'><div class='card-header'><div class='demo-facebook-avatar'><img src='https://nmaist.000webhostapp.com/upload/".$row['dp']."' alt='' style='width:34px;height:34px;border-radius:100%;' /> ".$row['username']."</div><div class='demo-facebook-date'>".$row['time']."</div></div><div class='card-content'> <h3 style='color:maroon;'>".$row['post']."</h3></div><div class='card-footer'> <span>".$row['date']." </span><span class='item-note'> ".$row['view']."  views</span></div></div></a>";
			echo $reslt;
			}
			
		}
		
			
   
}
}
 //echo json_encode($data);
//echo json_encode(new retObj('Success', $a[$id]));
?>