<?php
include "db.php";
$data=array();
$q=mysqli_query($con,"select * FROM `posts` JOIN `user` ON posts.email=user.email  ORDER BY id DESC");
while ($row= $q->fetch_assoc()){
 //$data[]=$row;
 if($row['source']){
 $reslt="<a class='item link external' href='bigview.html?id=".$row['id']."&email=".$row['email']."&username=".$row['username']."&posts=".$row['posts']."&view=".$row['view']."&Descriptions=".$row['Descriptions']."&source=".$row['source']."&dp=".$row['dp']."'><div class='card demo-facebook-card'  style='background-color:#ADD8E6;color:maroon;'><div class='card-header'><div class='demo-facebook-avatar'><img src='https://nmaist.000webhostapp.com/upload/".$row['dp']."' alt='' style='width:34px;height:34px; border-radius:100%;' /> ".$row['username']."</div><div class='demo-facebook-date'>".$row['time']."</div></div><div class='card-content' style='height: auto'> <h3 style='color:maroon;'>".$row['posts']."</h3><img src='https://nmaist.000webhostapp.com/upload/".$row['source']."' alt='' style='width:100%;height:100%;'></div><div class='card-footer'> <span>".$row['date']."</span><span class='item-note'> ".$row['view']."  views</span></div></div></a>";
 echo $reslt;
 }
 else if(!$row['source']){
 $reslt="<a class='item link external' href='bigview.html?id=".$row['id']."&email=".$row['email']."&username=".$row['username']."&posts=".$row['posts']."&view=".$row['view']."&Descriptions=".$row['Descriptions']."&dp=".$row['dp']."'><div class='card demo-facebook-card'  style='background-color:#ADD8E6;color:maroon;'><div class='card-header'><div class='demo-facebook-avatar'><img src='https://nmaist.000webhostapp.com/upload/".$row['dp']."' alt='' style='width:34px;height:34px; border-radius:100%;' /> ".$row['username']."</div><div class='demo-facebook-date'>".$row['time']."</div></div><div class='card-content' style='height: auto'> <h3 style='color:maroon;'>".$row['posts']."</h3></div><div class='card-footer'> <span>".$row['date']."</span><span class='item-note'> ".$row['view']."  views</span></div></div></a>";
 echo $reslt;
 }
 
 }
//echo json_encode($data);
?>